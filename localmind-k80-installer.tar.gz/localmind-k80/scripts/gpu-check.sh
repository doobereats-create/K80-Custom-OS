#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════
#  LocalMind K80 — GPU Diagnostics & Health Check
#  Run as: bash scripts/gpu-check.sh
# ═══════════════════════════════════════════════════════════════════
set -euo pipefail

RED='\033[0;31m'; YELLOW='\033[1;33m'; GREEN='\033[0;32m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

ok()   { echo -e "  ${GREEN}✓${NC}  $*"; }
warn() { echo -e "  ${YELLOW}⚠${NC}  $*"; }
fail() { echo -e "  ${RED}✗${NC}  $*"; FAILURES=$((FAILURES+1)); }
hdr()  { echo -e "\n${BOLD}${CYAN}── $* ──${NC}"; }

FAILURES=0

echo ""
echo -e "${BOLD}LocalMind K80 — Diagnostics Report${NC}"
echo -e "${CYAN}$(date)${NC}"
echo ""

# ── Driver ─────────────────────────────────────────────────────────
hdr "NVIDIA Driver"
if command -v nvidia-smi &>/dev/null; then
  DRIVER_VER=$(nvidia-smi --query-gpu=driver_version --format=csv,noheader | head -1)
  ok "nvidia-smi found — Driver: $DRIVER_VER"
  # Check for 470.xx series
  DRIVER_MAJOR=$(echo "$DRIVER_VER" | cut -d. -f1)
  if [[ "$DRIVER_MAJOR" -ge 470 && "$DRIVER_MAJOR" -lt 520 ]]; then
    ok "Driver version $DRIVER_VER is compatible with K80 (cc3.7)"
  elif [[ "$DRIVER_MAJOR" -ge 520 ]]; then
    warn "Driver $DRIVER_VER may drop K80 support — recommend 470.xx series"
  fi
else
  fail "nvidia-smi not found — driver not installed"
fi

# ── CUDA ───────────────────────────────────────────────────────────
hdr "CUDA Toolkit"
if command -v nvcc &>/dev/null; then
  CUDA_VER=$(nvcc --version | grep "release" | awk '{print $5}' | tr -d ',')
  ok "nvcc found — CUDA: $CUDA_VER"
  if echo "$CUDA_VER" | grep -qE "^11\.[0-4]"; then
    ok "CUDA $CUDA_VER supports K80 compute capability 3.7"
  elif echo "$CUDA_VER" | grep -qE "^12\."; then
    fail "CUDA 12.x does NOT support K80 (cc3.7) — must use CUDA 11.4 or earlier"
  fi
else
  warn "nvcc not found (CUDA toolkit not in PATH or not installed)"
  echo "    Expected: /usr/local/cuda-11.4/bin/nvcc"
fi

# ── GPU Detection ──────────────────────────────────────────────────
hdr "GPU Detection"
if command -v nvidia-smi &>/dev/null; then
  GPU_COUNT=$(nvidia-smi --list-gpus | wc -l)
  echo ""
  nvidia-smi --query-gpu=index,name,memory.total,compute_cap,temperature.gpu,power.draw,power.limit \
    --format=csv,noheader,nounits | while IFS=, read -r idx name mem cc temp pwr plimit; do
    echo -e "  GPU $idx: ${BOLD}$(echo $name | xargs)${NC}"
    echo -e "         VRAM: $(echo $mem | xargs) MiB  |  Compute: $(echo $cc | xargs)"
    echo -e "         Temp: $(echo $temp | xargs)°C  |  Power: $(echo $pwr | xargs)W / $(echo $plimit | xargs)W"
    if echo "$name" | grep -qi "K80"; then
      echo -e "         ${GREEN}✓ Tesla K80 confirmed${NC}"
    fi
  done
  echo ""
  ok "Total GPUs detected: $GPU_COUNT"
  [[ $GPU_COUNT -lt 4 ]] && warn "Expected 4+ GPU dies — check PCIe connections and BIOS 4G Decoding"
  [[ $GPU_COUNT -ge 4 ]] && ok "4+ GPU dies active"
else
  fail "Cannot check GPUs — nvidia-smi not available"
fi

# ── Persistence Mode ───────────────────────────────────────────────
hdr "Persistence Mode"
if command -v nvidia-smi &>/dev/null; then
  PM=$(nvidia-smi --query-gpu=persistence_mode --format=csv,noheader | head -1 | xargs)
  if [[ "$PM" == "Enabled" ]]; then
    ok "Persistence mode: Enabled"
  else
    warn "Persistence mode disabled — run: sudo nvidia-smi -pm 1"
  fi
fi

# ── Nouveau Blacklist ──────────────────────────────────────────────
hdr "Nouveau Driver"
if lsmod | grep -q nouveau; then
  fail "Nouveau driver is LOADED — this will conflict with NVIDIA driver"
  echo "    Fix: Add to /etc/modprobe.d/blacklist-nouveau.conf and reboot"
else
  ok "Nouveau driver: blacklisted / not loaded"
fi

# ── NVIDIA Container Toolkit ───────────────────────────────────────
hdr "Container Toolkit"
if command -v nvidia-ctk &>/dev/null; then
  ok "nvidia-ctk installed: $(nvidia-ctk --version 2>&1 | head -1)"
  # Check Docker runtime config
  if docker info 2>/dev/null | grep -qi nvidia; then
    ok "Docker NVIDIA runtime: configured"
  else
    warn "Docker NVIDIA runtime not configured — run: sudo nvidia-ctk runtime configure --runtime=docker"
  fi
else
  warn "nvidia-container-toolkit not found — needed for Docker GPU access"
fi

# ── Ollama ─────────────────────────────────────────────────────────
hdr "Ollama Service"
if command -v ollama &>/dev/null; then
  OLLAMA_VER=$(ollama --version 2>&1 | head -1)
  ok "Ollama installed: $OLLAMA_VER"
  if curl -s --max-time 3 http://localhost:11434/api/tags &>/dev/null; then
    ok "Ollama API responding at :11434"
    MODEL_COUNT=$(curl -s http://localhost:11434/api/tags | python3 -c "import sys,json; d=json.load(sys.stdin); print(len(d.get('models',[])))" 2>/dev/null || echo "?")
    ok "Models loaded: $MODEL_COUNT"
  else
    warn "Ollama API not responding — check: systemctl status ollama"
  fi
else
  fail "Ollama not found"
fi

# ── Open WebUI ─────────────────────────────────────────────────────
hdr "Open WebUI (Docker)"
if command -v docker &>/dev/null; then
  if docker ps 2>/dev/null | grep -q "open-webui"; then
    ok "open-webui container running"
    if curl -s --max-time 5 http://localhost:3000 &>/dev/null; then
      ok "Open WebUI responding at http://localhost:3000"
    else
      warn "Container running but port 3000 not responding yet"
    fi
  else
    warn "open-webui container not running"
    echo "    Start: cd /opt/localmind && docker compose up -d"
  fi
else
  warn "Docker not found"
fi

# ── System Resources ───────────────────────────────────────────────
hdr "System Resources"
RAM_TOTAL=$(awk '/MemTotal/ {printf "%.1f", $2/1024/1024}' /proc/meminfo)
RAM_FREE=$(awk '/MemAvailable/ {printf "%.1f", $2/1024/1024}' /proc/meminfo)
SWAP_TOTAL=$(awk '/SwapTotal/ {printf "%.1f", $2/1024/1024}' /proc/meminfo)
ok "RAM: ${RAM_FREE}GB free / ${RAM_TOTAL}GB total"
[[ $(echo "$SWAP_TOTAL > 0" | bc 2>/dev/null) -eq 1 ]] && \
  ok "Swap: ${SWAP_TOTAL}GB configured" || \
  warn "No swap configured — recommend 32GB for large model CPU offload"

DISK_FREE=$(df / --output=avail -BG | tail -1 | tr -d 'G ')
ok "Root disk: ${DISK_FREE}GB free"
[[ $DISK_FREE -lt 20 ]] && warn "Low disk space — models require 4–40GB each"

# ── Network ────────────────────────────────────────────────────────
hdr "Network"
LAN_IP=$(hostname -I | awk '{print $1}')
ok "LAN IP: $LAN_IP"
echo -e "  ${CYAN}Open WebUI:${NC}  http://${LAN_IP}:3000"
echo -e "  ${CYAN}Ollama API:${NC}  http://${LAN_IP}:11434"

# Check firewall
if command -v ufw &>/dev/null && ufw status 2>/dev/null | grep -q "Status: active"; then
  ok "Firewall: active"
  ufw status | grep -E "3000|11434" | while read -r line; do
    echo "    $line"
  done
else
  warn "Firewall not configured — run: sudo ufw allow 3000/tcp && sudo ufw allow 11434/tcp"
fi

# ── Summary ────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}── Summary ──${NC}"
if [[ $FAILURES -eq 0 ]]; then
  echo -e "  ${GREEN}${BOLD}All checks passed! ✓${NC}"
else
  echo -e "  ${RED}${BOLD}$FAILURES check(s) failed — review above${NC}"
fi
echo ""
