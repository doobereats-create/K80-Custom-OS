#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════
#  LocalMind K80 — Swap Setup
#  Creates 32GB swap for large model CPU offload
#  Run as root: sudo bash scripts/setup-swap.sh
# ═══════════════════════════════════════════════════════════════════
set -euo pipefail
[[ $EUID -ne 0 ]] && echo "Run as root" && exit 1

SWAP_FILE="/swapfile-localmind"
SWAP_SIZE_GB=${1:-32}

echo "Creating ${SWAP_SIZE_GB}GB swap at $SWAP_FILE..."

# Remove existing swap if present
[[ -f "$SWAP_FILE" ]] && swapoff "$SWAP_FILE" 2>/dev/null; rm -f "$SWAP_FILE"

# Create swap file
fallocate -l "${SWAP_SIZE_GB}G" "$SWAP_FILE"
chmod 600 "$SWAP_FILE"
mkswap "$SWAP_FILE"
swapon "$SWAP_FILE"

# Persist across reboots
grep -q "$SWAP_FILE" /etc/fstab || \
  echo "$SWAP_FILE none swap sw 0 0" >> /etc/fstab

# Tune swappiness for LLM workloads (prefer RAM, use swap only when needed)
sysctl -w vm.swappiness=10
grep -q "vm.swappiness" /etc/sysctl.conf && \
  sed -i "s/vm.swappiness.*/vm.swappiness=10/" /etc/sysctl.conf || \
  echo "vm.swappiness=10" >> /etc/sysctl.conf

# Increase vm.max_map_count for large mmap'd models
sysctl -w vm.max_map_count=262144
grep -q "vm.max_map_count" /etc/sysctl.conf || \
  echo "vm.max_map_count=262144" >> /etc/sysctl.conf

echo ""
echo "✓ Swap configured:"
swapon --show
echo ""
echo "  vm.swappiness = 10 (prefer RAM)"
echo "  vm.max_map_count = 262144 (for large model files)"
