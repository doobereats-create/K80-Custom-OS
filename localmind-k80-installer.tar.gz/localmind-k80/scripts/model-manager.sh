#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════
#  LocalMind K80 — Model Manager
#  Usage: bash scripts/model-manager.sh
# ═══════════════════════════════════════════════════════════════════

RED='\033[0;31m'; YELLOW='\033[1;33m'; GREEN='\033[0;32m'
CYAN='\033[0;36m'; BOLD='\033[1m'; MUTED='\033[2m'; NC='\033[0m'

log()  { echo -e "${CYAN}»${NC} $*"; }
ok()   { echo -e "${GREEN}✓${NC} $*"; }
warn() { echo -e "${YELLOW}⚠${NC} $*"; }
err()  { echo -e "${RED}✗${NC} $*"; }

check_ollama() {
  curl -s --max-time 3 http://localhost:11434/api/tags &>/dev/null || {
    err "Ollama not responding at :11434"
    echo "  Start it: sudo systemctl start ollama"
    exit 1
  }
}

# ── Model catalog (name, size, VRAM, description) ──────────────────
declare -A MODEL_DESC=(
  ["mistral:7b-instruct-q4_K_M"]="4.1GB | ~5GB VRAM | Best chat model for K80 single die"
  ["llama3.1:8b-instruct-q4_K_M"]="4.9GB | ~6GB VRAM | Meta's flagship 8B — strong reasoning"
  ["llama3.1:8b-instruct-q8_0"]="8.5GB | ~10GB VRAM | Higher quality 8B — fits in 12GB die"
  ["gemma2:9b-instruct-q4_K_M"]="5.4GB | ~6.5GB VRAM | Google Gemma2 — excellent QA"
  ["codellama:13b-code-q4_K_M"]="7.4GB | ~8.5GB VRAM | Best code generation"
  ["mistral:13b-instruct-q4_K_M"]="7.4GB | ~9GB VRAM | Larger Mistral — better coherence"
  ["llama3.1:70b-instruct-q4_K_M"]="39GB | ~40GB VRAM | Needs all 4 K80s. Slow but powerful."
  ["llama3.1:70b-instruct-q2_K"]="26GB | ~27GB VRAM | Compressed 70B — faster, lower quality"
  ["mixtral:8x7b-instruct-q4_K_M"]="26GB | ~28GB VRAM | MoE architecture — excellent quality"
  ["nomic-embed-text"]="274MB | ~1GB VRAM | Embeddings for RAG/document search"
  ["mxbai-embed-large"]="669MB | ~1.5GB VRAM | High-quality embeddings"
  ["llava:13b-v1.6-q4_K_M"]="8.0GB | ~9GB VRAM | Multimodal — image + text"
)

# ── List available models ──────────────────────────────────────────
list_catalog() {
  echo ""
  echo -e "${BOLD}  Available Models for K80 Rig:${NC}"
  echo ""
  printf "  %-45s %-12s %s\n" "MODEL" "STATUS" "DESCRIPTION"
  printf "  %-45s %-12s %s\n" "─────" "──────" "───────────"
  for model in "${!MODEL_DESC[@]}"; do
    if ollama list 2>/dev/null | grep -q "^${model%%:*}:"; then
      STATUS="${GREEN}installed${NC}"
    else
      STATUS="${MUTED}not pulled${NC}"
    fi
    printf "  %-45s %-20s %s\n" "$model" "$STATUS" "${MODEL_DESC[$model]}"
  done | sort
  echo ""
}

# ── Pull models ────────────────────────────────────────────────────
pull_model() {
  local model="$1"
  log "Pulling $model..."
  if ollama pull "$model"; then
    ok "$model pulled successfully"
    # Create K80-optimized variant if modelfile exists
    MFILE="/etc/ollama/modelfiles/Modelfile.$(echo "$model" | tr ':.' '-' | cut -d- -f1,2)-k80"
    if [[ -f "$MFILE" ]]; then
      local custom_name
      custom_name="$(echo "$model" | cut -d: -f1)-k80"
      log "Creating K80-optimized variant: $custom_name"
      ollama create "$custom_name" -f "$MFILE" && ok "Created $custom_name"
    fi
  else
    err "Failed to pull $model"
  fi
}

# ── Benchmark a model ──────────────────────────────────────────────
benchmark_model() {
  local model="$1"
  echo ""
  log "Benchmarking $model on K80..."
  echo -e "${MUTED}  Test: generating 200 tokens from a standard prompt${NC}"
  echo ""

  local prompt="Explain the concept of machine learning in exactly 3 paragraphs, covering: what it is, how it works, and where it is used."
  local start_time
  start_time=$(date +%s%3N)

  local response
  response=$(curl -s http://localhost:11434/api/generate \
    -d "{\"model\":\"$model\",\"prompt\":\"$prompt\",\"stream\":false,\"options\":{\"num_predict\":200}}" \
    2>/dev/null)

  local end_time
  end_time=$(date +%s%3N)
  local elapsed=$(( end_time - start_time ))

  local tokens
  tokens=$(echo "$response" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('eval_count',0))" 2>/dev/null || echo "0")
  local prompt_tokens
  prompt_tokens=$(echo "$response" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('prompt_eval_count',0))" 2>/dev/null || echo "0")

  if [[ $tokens -gt 0 && $elapsed -gt 0 ]]; then
    local tps=$(echo "scale=1; $tokens * 1000 / $elapsed" | bc 2>/dev/null || echo "?")
    ok "Results:"
    echo "    Prompt tokens:    $prompt_tokens"
    echo "    Generated tokens: $tokens"
    echo "    Total time:       ${elapsed}ms"
    echo -e "    ${BOLD}Tokens/second:    ${GREEN}${tps} t/s${NC}"
  else
    warn "Benchmark failed or returned no tokens"
  fi
  echo ""

  # GPU stats after benchmark
  if command -v nvidia-smi &>/dev/null; then
    echo -e "${MUTED}  GPU state after inference:${NC}"
    nvidia-smi --query-gpu=index,memory.used,memory.total,utilization.gpu \
      --format=csv,noheader,nounits | while IFS=, read -r idx mem_used mem_total util; do
      echo "    GPU $idx: ${mem_used}MB / ${mem_total}MB VRAM  |  ${util}% util"
    done
    echo ""
  fi
}

# ── Remove model ───────────────────────────────────────────────────
remove_model() {
  echo ""
  log "Installed models:"
  ollama list
  echo ""
  read -rp "  Model to remove (exact name:tag): " model
  [[ -z "$model" ]] && return
  read -rp "  Remove '$model'? [y/N]: " confirm
  [[ ! "$confirm" =~ ^[Yy]$ ]] && return
  ollama rm "$model" && ok "Removed $model" || err "Failed to remove $model"
}

# ── Show disk usage ────────────────────────────────────────────────
show_usage() {
  echo ""
  log "Model storage:"
  local model_dir="${HOME}/.ollama/models"
  [[ -d /usr/share/ollama/.ollama/models ]] && model_dir="/usr/share/ollama/.ollama/models"
  if [[ -d "$model_dir" ]]; then
    du -sh "$model_dir" 2>/dev/null && echo ""
    du -sh "$model_dir/blobs/"* 2>/dev/null | sort -rh | head -20 || true
  fi
  echo ""
  df -h / | tail -1 | awk '{print "  Root disk: "$4" free of "$2}'
  echo ""
}

# ── Main Menu ──────────────────────────────────────────────────────
main_menu() {
  check_ollama
  while true; do
    echo ""
    echo -e "${BOLD}${CYAN}LocalMind K80 — Model Manager${NC}"
    echo ""
    echo -e "  ${GREEN}[1]${NC} List available models (catalog)"
    echo -e "  ${CYAN}[2]${NC} List installed models"
    echo -e "  ${CYAN}[3]${NC} Pull a model"
    echo -e "  ${CYAN}[4]${NC} Benchmark a model"
    echo -e "  ${YELLOW}[5]${NC} Remove a model"
    echo -e "  ${CYAN}[6]${NC} Show disk usage"
    echo -e "  ${CYAN}[7]${NC} GPU status"
    echo -e "  ${RED}[0]${NC} Exit"
    echo ""
    read -rp "  Choice: " CHOICE
    case "$CHOICE" in
      1) list_catalog ;;
      2) echo "" && ollama list ;;
      3)
        list_catalog
        read -rp "  Model name to pull: " m
        [[ -n "$m" ]] && pull_model "$m"
        ;;
      4)
        echo "" && ollama list && echo ""
        read -rp "  Model to benchmark: " m
        [[ -n "$m" ]] && benchmark_model "$m"
        ;;
      5) remove_model ;;
      6) show_usage ;;
      7) echo "" && nvidia-smi 2>/dev/null || echo "nvidia-smi not found" ;;
      0) exit 0 ;;
      *) warn "Invalid choice" ;;
    esac
  done
}

main_menu
