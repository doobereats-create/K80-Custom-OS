# LocalMind K80 — Installation Package

**Local LLM stack for Ubuntu 22.04 with Open WebUI (Open Claw) and Ollama**  
Optimized for: TB360-BTC D+ | Intel i5-8500 | 16GB DDR4 | 4× Tesla K80

---

## Hardware Summary

| Component | Spec |
|-----------|------|
| Motherboard | TB360-BTC D+ (12× PCIe slots, LGA1151) |
| CPU | Intel i5-8500 — 6 Core, 3.0GHz, 9MB cache |
| RAM | 16GB DDR4 |
| GPU | 4× NVIDIA Tesla K80 — 12GB GDDR5 each (48GB total) |
| CUDA Compute | 3.7 (GK210) — **max supported CUDA: 11.4** |

---

## Quick Start

```bash
# 1. Transfer this folder to your Ubuntu 22.04 machine
scp -r localmind-k80/ user@YOUR_SERVER_IP:~/

# 2. Run the installer as root
cd localmind-k80
sudo bash install.sh
```

The installer will guide you through all phases with a menu.

---

## Package Contents

```
localmind-k80/
├── install.sh                    ← Master installer (run this)
├── README.md                     ← This file
│
├── systemd/
│   ├── ollama.service            ← K80-optimized Ollama service
│   ├── nvidia-k80-settings.service  ← GPU persistence + power config
│   └── localmind-webui.service   ← Open WebUI Docker auto-start
│
├── docker/
│   ├── docker-compose.yml        ← Open WebUI Docker Compose
│   └── .env                      ← Environment config
│
├── modelfiles/
│   ├── Modelfile.mistral-k80     ← Mistral 7B (K80-tuned)
│   ├── Modelfile.llama31-k80     ← Llama 3.1 8B (K80-tuned)
│   └── Modelfile.codellama-k80   ← CodeLlama 13B (K80-tuned)
│
├── scripts/
│   ├── gpu-check.sh              ← Full diagnostics & health check
│   ├── model-manager.sh          ← Pull / benchmark / remove models
│   └── setup-swap.sh             ← 32GB swap for large model offload
│
└── monitoring/
    └── monitor.sh                ← Live GPU + system dashboard
```

---

## Installation Phases

### Phase 1 — BIOS (manual, before install)
- PCIe Speed → **GEN2**
- Above 4G Decoding → **ENABLED**
- Re-Size BAR → **DISABLED**
- VT-d → **ENABLED**

### Phase 2 — Base System
Installs: build-essential, docker, linux-headers, python3, nvtop, etc.  
Blacklists Nouveau driver.

### Phase 3 — NVIDIA Driver 470 + CUDA 11.4
⚠ **Critical:** K80 = CUDA cc3.7. CUDA 12.x will **not work**.  
Installs driver 470.xx + CUDA 11.4 toolkit + NVIDIA Container Toolkit.

### Phase 4 — Ollama
Installs Ollama with K80-optimized systemd service:
- `CUDA_VISIBLE_DEVICES=0,1,2,3`
- `OLLAMA_FLASH_ATTENTION=0` (K80 doesn't support it)
- `OLLAMA_NUM_GPU=4`

### Phase 5 — Open WebUI
Deploys via Docker at `http://YOUR_IP:3000`.  
First user to register becomes admin.

### Phase 6 — Models
Pulls starter models. Recommended for K80:
- `mistral:7b-instruct-q4_K_M` — fast, excellent chat (~5GB VRAM)
- `llama3.1:8b-instruct-q4_K_M` — strong reasoning (~6GB VRAM)
- `codellama:13b-code-q4_K_M` — code generation (~8.5GB VRAM)

---

## Utility Scripts

```bash
# GPU diagnostics and health check
bash scripts/gpu-check.sh

# Interactive model manager (pull / benchmark / remove)
bash scripts/model-manager.sh

# Live GPU + system monitor (refreshes every 2s)
bash monitoring/monitor.sh

# Set up 32GB swap (for large model CPU offload)
sudo bash scripts/setup-swap.sh
```

---

## After Install

```bash
# Check everything is working
bash scripts/gpu-check.sh

# Pull your first model
ollama pull mistral:7b-instruct-q4_K_M

# Chat via terminal
ollama run mistral:7b-instruct-q4_K_M

# Access the web UI
http://YOUR_LAN_IP:3000
```

---

## K80 Performance Expectations

| Model | VRAM | Tokens/sec (est.) |
|-------|------|-------------------|
| 7B Q4_K_M | ~5GB (1 GPU) | 20–40 t/s |
| 8B Q4_K_M | ~6GB (1 GPU) | 18–35 t/s |
| 13B Q4_K_M | ~8.5GB (1 GPU) | 12–22 t/s |
| 70B Q4_K_M | ~40GB (4 GPUs) | 3–6 t/s |

---

## Troubleshooting

**GPUs not detected by Ollama:**
```bash
nvidia-smi  # Verify driver sees all GPUs
systemctl restart ollama
journalctl -u ollama -f  # Check logs
```

**CUDA errors / "no kernel image":**
```bash
nvcc --version  # Must show 11.4, not 12.x
```

**K80 showing 2 devices per card (8 total instead of 4):**  
This is normal — each K80 has 2 GK210 dies. Ollama will use all 8 logical GPUs automatically.

**Out of VRAM on 70B model:**
```bash
# Use lower quantization
ollama pull llama3.1:70b-instruct-q2_K
# Or set up swap first
sudo bash scripts/setup-swap.sh
```
