#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════
#  LocalMind K80 — Master Installer
#  Hardware: TB360-BTC D+ | i5-8500 | 16GB DDR4 | 4× Tesla K80
#  Stack:    Ubuntu 22.04 LTS | CUDA 11.4 | Ollama | Open WebUI
# ═══════════════════════════════════════════════════════════════════
set -euo pipefail

# ── Colors ──────────────────────────────────────────────────────────
RED='\033[0;31m'; YELLOW='\033[1;33m'; GREEN='\033[0;32m'
CYAN='\033[0;36m'; BLUE='\033[0;34m'; BOLD='\033[1m'; NC='\033[0m'

# ── Paths ────────────────────────────────────────────────────────────
INSTALLER_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="/var/log/localmind-install.log"
INSTALL_USER="${SUDO_USER:-$USER}"

# ── Logging ──────────────────────────────────────────────────────────
log()  { echo -e "${CYAN}[INFO]${NC}  $*" | tee -a "$LOG_FILE"; }
ok()   { echo -e "${GREEN}[OK]${NC}    $*" | tee -a "$LOG_FILE"; }
warn() { echo -e "${YELLOW}[WARN]${NC}  $*" | tee -a "$LOG_FILE"; }
err()  { echo -e "${RED}[ERROR]${NC} $*" | tee -a "$LOG_FILE"; exit 1; }
step() { echo -e "\n${BOLD}${BLUE}══ $* ${NC}" | tee -a "$LOG_FILE"; }

# ── Banner ────────────────────────────────────────────────────────────
banner() {
cat << 'EOF'
  ██╗      ██████╗  ██████╗ █████╗ ██╗     ███╗   ███╗██╗███╗   ██╗██████╗
  ██║     ██╔═══██╗██╔════╝██╔══██╗██║     ████╗ ████║██║████╗  ██║██╔══██╗
  ██║     ██║   ██║██║     ███████║██║     ██╔████╔██║██║██╔██╗ ██║██║  ██║
  ██║     ██║   ██║██║     ██╔══██║██║     ██║╚██╔╝██║██║██║╚██╗██║██║  ██║
  ███████╗╚██████╔╝╚██████╗██║  ██║███████╗██║ ╚═╝ ██║██║██║ ╚████║██████╔╝
  ╚══════╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝     ╚═╝╚═╝╚═╝  ╚═══╝╚═════╝
                         K80 Edition — LLM Stack Installer
EOF
  echo -e "  ${CYAN}Hardware:${NC} TB360-BTC D+ | i5-8500 6C | 16GB DDR4 | 4× Tesla K80 (48GB)"
  echo -e "  ${CYAN}Stack:${NC}    Ubuntu 22.04 | CUDA 11.4 | Ollama | Open WebUI"
  echo -e "  ${YELLOW}──────────────────────────────────────────────────────────────────${NC}\n"
}

# ── Pre-flight checks ─────────────────────────────────────────────────
preflight() {
  step "Pre-flight Checks"

  [[ $EUID -ne 0 ]] && err "Run as root: sudo bash install.sh"

  # OS check
  . /etc/os-release
  [[ "$ID" != "ubuntu" ]] && err "Ubuntu required. Found: $ID"
  [[ "$VERSION_ID" != "22.04" ]] && warn "Tested on 22.04, found $VERSION_ID — continuing..."
  ok "OS: Ubuntu $VERSION_ID"

  # RAM check
  RAM_GB=$(awk '/MemTotal/ {printf "%.0f", $2/1024/1024}' /proc/meminfo)
  [[ $RAM_GB -lt 14 ]] && warn "Less than 16GB RAM detected (${RAM_GB}GB). Large models may need swap."
  ok "RAM: ${RAM_GB}GB"

  # Disk check
  FREE_GB=$(df / --output=avail -BG | tail -1 | tr -d 'G ')
  [[ $FREE_GB -lt 50 ]] && warn "Less than 50GB free (${FREE_GB}GB). Recommend 100GB+ for models."
  ok "Disk: ${FREE_GB}GB free"

  # Internet
  curl -s --max-time 5 https://google.com > /dev/null || err "No internet connection."
  ok "Network: connected"

  # CPU check
  CPU_CORES=$(nproc)
  ok "CPU: $(grep 'model name' /proc/cpuinfo | head -1 | cut -d: -f2 | xargs) (${CPU_CORES} threads)"

  touch "$LOG_FILE"
  ok "Log: $LOG_FILE"
}

# ── Select modules ────────────────────────────────────────────────────
select_modules() {
  step "Installation Modules"
  echo ""
  echo -e "  ${BOLD}Select what to install:${NC}"
  echo ""
  echo -e "  ${GREEN}[1]${NC} Full Stack (Recommended) — Base + CUDA + Ollama + Open WebUI + Models"
  echo -e "  ${CYAN}[2]${NC} Base + CUDA + Ollama only (no WebUI)"
  echo -e"  ${CYAN}[3]${NC} Open WebUI only (Ollama already installed)"
  echo -e "  ${CYAN}[4]${NC} Custom — choose each component"
  echo -e "  ${YELLOW}[5]${NC} Uninstall / Clean everything"
  echo ""
  read -rp "  Choice [1-5]: " CHOICE

  case "$CHOICE" in
    1) DO_BASE=1; DO_CUDA=1; DO_OLLAMA=1; DO_WEBUI=1; DO_MODELS=1 ;;
    2) DO_BASE=1; DO_CUDA=1; DO_OLLAMA=1; DO_WEBUI=0; DO_MODELS=0 ;;
    3) DO_BASE=0; DO_CUDA=0; DO_OLLAMA=0; DO_WEBUI=1; DO_MODELS=0 ;;
    4) custom_select ;;
    5) run_uninstall; exit 0 ;;
    *) err "Invalid choice" ;;
  esac
}

custom_select() {
  yesno() { read -rp "  Install $1? [y/N]: " r; [[ "$r" =~ ^[Yy]$ ]] && echo 1 || echo 0; }
  DO_BASE=$(yesno "base system packages")
  DO_CUDA=$(yesno "NVIDIA Driver 470 + CUDA 11.4")
  DO_OLLAMA=$(yesno "Ollama LLM engine")
  DO_WEBUI=$(yesno "Open WebUI (Open Claw)")
  DO_MODELS=$(yesno "starter model pack")
}

# ── Module: Base System ───────────────────────────────────────────────
install_base() {
  step "Base System Packages"
  apt-get update -qq
  apt-get install -y \
    build-essential dkms git curl wget unzip htop nvtop net-tools \
    python3 python3-pip python3-venv \
    ca-certificates gnupg lsb-release apt-transport-https \
    software-properties-common pciutils usbutils \
    linux-headers-"$(uname -r)" \
    docker.io docker-compose-v2 \
    jq bc lm-sensors 2>&1 | tee -a "$LOG_FILE"

  # Docker
  systemctl enable --now docker
  usermod -aG docker "$INSTALL_USER"
  ok "Docker enabled"

  # Blacklist Nouveau
  cat > /etc/modprobe.d/blacklist-nouveau.conf << 'EOF'
blacklist nouveau
options nouveau modeset=0
EOF
  update-initramfs -u -k all >> "$LOG_FILE" 2>&1
  ok "Nouveau blacklisted"

  ok "Base packages installed"
}

# ── Module: NVIDIA Driver + CUDA 11.4 ────────────────────────────────
install_cuda() {
  step "NVIDIA Driver 470 + CUDA 11.4"

  # Check if driver already present
  if nvidia-smi &>/dev/null; then
    warn "NVIDIA driver already detected — skipping driver install"
    nvidia-smi | tee -a "$LOG_FILE"
  else
    log "Adding graphics-drivers PPA..."
    add-apt-repository -y ppa:graphics-drivers/ppa >> "$LOG_FILE" 2>&1
    apt-get update -qq
    apt-get install -y nvidia-driver-470 nvidia-utils-470 2>&1 | tee -a "$LOG_FILE"
    ok "Driver 470 installed — reboot required"
    NEED_REBOOT=1
  fi

  # CUDA 11.4
  if nvcc --version 2>/dev/null | grep -q "11.4"; then
    warn "CUDA 11.4 already installed — skipping"
  else
    log "Downloading CUDA 11.4 toolkit..."
    CUDA_INSTALLER="/tmp/cuda_11.4.0_linux.run"
    wget -q --show-progress \
      "https://developer.download.nvidia.com/compute/cuda/11.4.0/local_installers/cuda_11.4.0_470.42.01_linux.run" \
      -O "$CUDA_INSTALLER"

    log "Installing CUDA 11.4..."
    bash "$CUDA_INSTALLER" --silent --toolkit --no-drm --no-opengl-libs 2>&1 | tee -a "$LOG_FILE"
    rm -f "$CUDA_INSTALLER"
  fi

  # Environment variables
  cat > /etc/profile.d/cuda.sh << 'EOF'
export PATH=/usr/local/cuda-11.4/bin${PATH:+:${PATH}}
export LD_LIBRARY_PATH=/usr/local/cuda-11.4/lib64${LD_LIBRARY_PATH:+:${LD_LIBRARY_PATH}}
EOF
  chmod +x /etc/profile.d/cuda.sh
  source /etc/profile.d/cuda.sh

  # Install NVIDIA Container Toolkit
  log "Installing NVIDIA Container Toolkit..."
  curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey \
    | gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
  curl -s -L "https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list" \
    | sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' \
    | tee /etc/apt/sources.list.d/nvidia-container-toolkit.list
  apt-get update -qq
  apt-get install -y nvidia-container-toolkit 2>&1 | tee -a "$LOG_FILE"
  nvidia-ctk runtime configure --runtime=docker >> "$LOG_FILE" 2>&1
  systemctl restart docker

  # K80 persistence + power service
  cp "$INSTALLER_DIR/systemd/nvidia-k80-settings.service" /etc/systemd/system/
  systemctl daemon-reload
  systemctl enable nvidia-k80-settings.service
  ok "NVIDIA K80 settings service installed"

  ok "CUDA 11.4 + Container Toolkit installed"
}

# ── Module: Ollama ────────────────────────────────────────────────────
install_ollama() {
  step "Ollama LLM Engine"

  log "Installing Ollama..."
  curl -fsSL https://ollama.com/install.sh | OLLAMA_GPU=1 sh 2>&1 | tee -a "$LOG_FILE"

  # Install optimized service file
  log "Installing K80-optimized Ollama service..."
  cp "$INSTALLER_DIR/systemd/ollama.service" /etc/systemd/system/ollama.service
  systemctl daemon-reload
  systemctl enable --now ollama

  # Wait for Ollama to start
  log "Waiting for Ollama to start..."
  for i in {1..20}; do
    curl -s http://localhost:11434/api/tags &>/dev/null && break
    sleep 2
  done

  if curl -s http://localhost:11434/api/tags &>/dev/null; then
    ok "Ollama running at http://localhost:11434"
  else
    warn "Ollama may need reboot to start (CUDA driver reload required)"
  fi

  # Install modelfiles
  mkdir -p /etc/ollama/modelfiles
  cp "$INSTALLER_DIR/modelfiles/"* /etc/ollama/modelfiles/
  ok "Modelfiles installed to /etc/ollama/modelfiles"
}

# ── Module: Open WebUI ────────────────────────────────────────────────
install_webui() {
  step "Open WebUI (Open Claw)"

  # Copy docker-compose
  mkdir -p /opt/localmind
  cp "$INSTALLER_DIR/docker/docker-compose.yml" /opt/localmind/
  cp "$INSTALLER_DIR/docker/.env" /opt/localmind/

  # Generate random secret key
  SECRET=$(openssl rand -hex 32)
  sed -i "s/CHANGE_THIS_SECRET/$SECRET/" /opt/localmind/.env

  log "Pulling Open WebUI Docker image..."
  cd /opt/localmind
  docker compose pull 2>&1 | tee -a "$LOG_FILE"

  log "Starting Open WebUI..."
  docker compose up -d 2>&1 | tee -a "$LOG_FILE"

  # Install systemd service for auto-start
  cp "$INSTALLER_DIR/systemd/localmind-webui.service" /etc/systemd/system/
  systemctl daemon-reload
  systemctl enable localmind-webui.service

  # Wait for startup
  log "Waiting for Open WebUI..."
  for i in {1..30}; do
    curl -s http://localhost:3000 &>/dev/null && break
    sleep 3
  done

  ok "Open WebUI running at http://localhost:3000"
}

# ── Module: Starter Models ────────────────────────────────────────────
install_models() {
  step "Starter Model Pack"
  echo ""
  echo -e "  ${BOLD}Choose model pack:${NC}"
  echo -e "  ${GREEN}[1]${NC} Minimal  — mistral:7b only              (~4GB)"
  echo -e "  ${CYAN}[2]${NC} Standard — mistral:7b + llama3.1:8b + nomic-embed  (~12GB)"
  echo -e "  ${CYAN}[3]${NC} Full     — Standard + codellama:13b + mixtral:8x7b (~50GB)"
  echo -e "  ${YELLOW}[0]${NC} Skip models (pull manually later)"
  echo ""
  read -rp "  Choice [0-3]: " MODEL_CHOICE

  pull_model() {
    log "Pulling $1..."
    ollama pull "$1" 2>&1 | tee -a "$LOG_FILE" && ok "Pulled: $1" || warn "Failed to pull $1"
  }

  # Always pull embedding model if WebUI installed
  [[ ${DO_WEBUI:-0} -eq 1 ]] && pull_model "nomic-embed-text"

  case "$MODEL_CHOICE" in
    1) pull_model "mistral:7b-instruct-q4_K_M" ;;
    2)
      pull_model "mistral:7b-instruct-q4_K_M"
      pull_model "llama3.1:8b-instruct-q4_K_M"
      pull_model "nomic-embed-text"
      ;;
    3)
      pull_model "mistral:7b-instruct-q4_K_M"
      pull_model "llama3.1:8b-instruct-q4_K_M"
      pull_model "codellama:13b-code-q4_K_M"
      pull_model "mixtral:8x7b-instruct-q4_K_M"
      pull_model "nomic-embed-text"
      ;;
    0) log "Skipping models. Pull manually with: ollama pull <model>" ;;
    *) warn "Invalid choice — skipping models" ;;
  esac

  # Create K80-optimized custom model variants
  if ollama list 2>/dev/null | grep -q "mistral:7b-instruct"; then
    log "Creating K80-optimized mistral variant..."
    ollama create mistral-k80 -f /etc/ollama/modelfiles/Modelfile.mistral-k80 2>&1 | tee -a "$LOG_FILE"
    ok "Custom model 'mistral-k80' created"
  fi
}

# ── Uninstaller ───────────────────────────────────────────────────────
run_uninstall() {
  step "Uninstalling LocalMind K80"
  warn "This will remove Ollama, Open WebUI Docker containers, and configs."
  read -rp "  Type YES to confirm: " CONFIRM
  [[ "$CONFIRM" != "YES" ]] && { log "Aborted."; return; }

  # Stop services
  systemctl stop ollama localmind-webui 2>/dev/null || true
  systemctl disable ollama localmind-webui 2>/dev/null || true

  # Docker cleanup
  cd /opt/localmind && docker compose down -v 2>/dev/null || true

  # Remove files
  rm -f /etc/systemd/system/ollama.service
  rm -f /etc/systemd/system/localmind-webui.service
  rm -f /etc/systemd/system/nvidia-k80-settings.service
  rm -rf /opt/localmind
  rm -rf /etc/ollama

  # Ollama binary
  [[ -f /usr/local/bin/ollama ]] && rm -f /usr/local/bin/ollama
  [[ -d /usr/share/ollama ]] && rm -rf /usr/share/ollama

  systemctl daemon-reload
  ok "LocalMind K80 removed"
}

# ── Summary ───────────────────────────────────────────────────────────
print_summary() {
  LAN_IP=$(hostname -I | awk '{print $1}')
  echo ""
  echo -e "${GREEN}${BOLD}╔══════════════════════════════════════════════════════╗${NC}"
  echo -e "${GREEN}${BOLD}║          INSTALLATION COMPLETE ✓                    ║${NC}"
  echo -e "${GREEN}${BOLD}╚══════════════════════════════════════════════════════╝${NC}"
  echo ""
  [[ ${DO_WEBUI:-0} -eq 1 ]] && \
    echo -e "  ${BOLD}Open WebUI:${NC}   ${CYAN}http://${LAN_IP}:3000${NC}  (first user = admin)"
  [[ ${DO_OLLAMA:-0} -eq 1 ]] && \
    echo -e "  ${BOLD}Ollama API:${NC}   ${CYAN}http://${LAN_IP}:11434${NC}"
  echo ""
  echo -e "  ${BOLD}GPU Status:${NC}   nvidia-smi"
  echo -e "  ${BOLD}Live Monitor:${NC} nvtop"
  echo -e "  ${BOLD}Pull Model:${NC}   ollama pull mistral:7b-instruct-q4_K_M"
  echo -e "  ${BOLD}Log file:${NC}     $LOG_FILE"
  echo ""
  if [[ ${NEED_REBOOT:-0} -eq 1 ]]; then
    echo -e "  ${YELLOW}${BOLD}⚠  REBOOT REQUIRED to activate NVIDIA driver${NC}"
    echo -e "  ${YELLOW}   Run: sudo reboot${NC}"
  fi
  echo ""
}

# ── Main ──────────────────────────────────────────────────────────────
main() {
  clear
  banner
  preflight
  select_modules
  [[ ${DO_BASE:-0} -eq 1 ]]   && install_base
  [[ ${DO_CUDA:-0} -eq 1 ]]   && install_cuda
  [[ ${DO_OLLAMA:-0} -eq 1 ]] && install_ollama
  [[ ${DO_WEBUI:-0} -eq 1 ]]  && install_webui
  [[ ${DO_MODELS:-0} -eq 1 ]] && install_models
  print_summary
}

main "$@"
