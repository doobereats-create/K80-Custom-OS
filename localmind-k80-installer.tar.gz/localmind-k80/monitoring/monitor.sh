#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════
#  LocalMind K80 — Live System Monitor
#  Refreshes every 2 seconds. Press Ctrl+C to exit.
# ═══════════════════════════════════════════════════════════════════

INTERVAL=${1:-2}

# Colors
R='\033[0;31m'; Y='\033[1;33m'; G='\033[0;32m'
C='\033[0;36m'; B='\033[0;34m'; M='\033[0;35m'
BOLD='\033[1m'; DIM='\033[2m'; NC='\033[0m'

bar() {
  local pct=$1 width=${2:-20}
  local filled=$(( pct * width / 100 ))
  local empty=$(( width - filled ))
  printf "${G}"; printf '█%.0s' $(seq 1 $filled) 2>/dev/null || true
  printf "${DIM}"; printf '░%.0s' $(seq 1 $empty) 2>/dev/null || true
  printf "${NC}"
}

monitor_loop() {
  while true; do
    clear
    echo -e "${BOLD}${C}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BOLD}${C}║         LocalMind K80 — Live Monitor  $(date '+%H:%M:%S')              ║${NC}"
    echo -e "${BOLD}${C}╚══════════════════════════════════════════════════════════════╝${NC}"

    # ── GPU Section ─────────────────────────────────────────────────
    if command -v nvidia-smi &>/dev/null; then
      echo -e "\n${BOLD}  GPU CLUSTER  — Tesla K80 × 4${NC}"
      echo -e "  ${DIM}─────────────────────────────────────────────────────────────${NC}"

      nvidia-smi --query-gpu=index,name,memory.used,memory.total,utilization.gpu,utilization.memory,temperature.gpu,power.draw,power.limit,clocks.current.sm \
        --format=csv,noheader,nounits 2>/dev/null | while IFS=, read -r idx name mem_u mem_t gpu_u mem_u_pct temp pwr plimit clk; do
        local vram_pct=$(( ${mem_u%% *} * 100 / ${mem_t%% *} ))

        printf "  ${BOLD}GPU%-2s${NC} ${C}%-16s${NC}" "$idx" "$(echo $name | xargs | cut -c1-16)"
        printf " VRAM: "
        bar $vram_pct 16
        printf " ${BOLD}%5s${NC}/${mem_t%% *}MB" "${mem_u%% *}"
        printf "  GPU: "
        bar ${gpu_u%% *} 10
        printf " ${BOLD}%3s%%${NC}" "${gpu_u%% *}"
        printf "  ${Y}%3s°C${NC}" "${temp%% *}"
        printf "  ${M}%4sW${NC}\n" "${pwr%% *}"
      done
    else
      echo -e "  ${R}nvidia-smi not found${NC}"
    fi

    # ── System Memory ────────────────────────────────────────────────
    echo -e "\n${BOLD}  SYSTEM MEMORY${NC}"
    echo -e "  ${DIM}─────────────────────────────────────────────────────────────${NC}"
    RAM_TOTAL=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
    RAM_FREE=$(awk '/MemAvailable/ {print $2}' /proc/meminfo)
    RAM_USED=$(( RAM_TOTAL - RAM_FREE ))
    RAM_PCT=$(( RAM_USED * 100 / RAM_TOTAL ))
    SWAP_TOTAL=$(awk '/SwapTotal/ {print $2}' /proc/meminfo)
    SWAP_FREE=$(awk '/SwapFree/ {print $2}' /proc/meminfo)
    SWAP_USED=$(( SWAP_TOTAL - SWAP_FREE ))

    printf "  ${BOLD}RAM  ${NC}"
    bar $RAM_PCT 30
    printf "  ${BOLD}%5s${NC}/%sMB  (%s%%)\n" \
      "$(( RAM_USED / 1024 ))" "$(( RAM_TOTAL / 1024 ))" "$RAM_PCT"

    if [[ $SWAP_TOTAL -gt 0 ]]; then
      SWAP_PCT=$(( SWAP_USED * 100 / SWAP_TOTAL ))
      printf "  ${BOLD}SWAP ${NC}"
      bar $SWAP_PCT 30
      printf "  ${BOLD}%5s${NC}/%sMB  (%s%%)\n" \
        "$(( SWAP_USED / 1024 ))" "$(( SWAP_TOTAL / 1024 ))" "$SWAP_PCT"
    fi

    # ── CPU ──────────────────────────────────────────────────────────
    echo -e "\n${BOLD}  CPU — Intel i5-8500 (6C)${NC}"
    echo -e "  ${DIM}─────────────────────────────────────────────────────────────${NC}"
    CPU_LOAD=$(awk '{print $1,$2,$3}' /proc/loadavg)
    CPU_CORES=$(nproc)
    printf "  Load avg: ${BOLD}%s${NC}  (cores: %s)\n" "$CPU_LOAD" "$CPU_CORES"

    # CPU temp if available
    if command -v sensors &>/dev/null; then
      CPU_TEMP=$(sensors 2>/dev/null | grep 'Core 0' | awk '{print $3}' | head -1)
      [[ -n "$CPU_TEMP" ]] && printf "  CPU Temp: ${Y}%s${NC}\n" "$CPU_TEMP"
    fi

    # ── Ollama Status ────────────────────────────────────────────────
    echo -e "\n${BOLD}  OLLAMA ENGINE${NC}"
    echo -e "  ${DIM}─────────────────────────────────────────────────────────────${NC}"
    if curl -s --max-time 2 http://localhost:11434/api/tags &>/dev/null; then
      echo -e "  Status: ${G}● ONLINE${NC}  :11434"
      ACTIVE=$(curl -s http://localhost:11434/api/ps 2>/dev/null | python3 -c \
        "import sys,json; d=json.load(sys.stdin); [print('  Active: '+m['name']) for m in d.get('models',[])]" 2>/dev/null || true)
      [[ -n "$ACTIVE" ]] && echo -e "$ACTIVE" || echo -e "  ${DIM}No model currently loaded${NC}"
    else
      echo -e "  Status: ${R}● OFFLINE${NC}"
    fi

    # ── Open WebUI ───────────────────────────────────────────────────
    echo -e "\n${BOLD}  OPEN WEBUI${NC}"
    echo -e "  ${DIM}─────────────────────────────────────────────────────────────${NC}"
    if command -v docker &>/dev/null && docker ps 2>/dev/null | grep -q "open-webui"; then
      LAN_IP=$(hostname -I | awk '{print $1}')
      echo -e "  Status: ${G}● RUNNING${NC}  → ${C}http://${LAN_IP}:3000${NC}"
    else
      echo -e "  Status: ${Y}● STOPPED${NC}"
    fi

    # ── Disk ─────────────────────────────────────────────────────────
    echo -e "\n${BOLD}  STORAGE${NC}"
    echo -e "  ${DIM}─────────────────────────────────────────────────────────────${NC}"
    df -h / | awk 'NR>1 {printf "  Root: %s used, %s free of %s\n", $3, $4, $2}'

    echo ""
    echo -e "  ${DIM}Refreshing every ${INTERVAL}s — Ctrl+C to exit${NC}"
    sleep "$INTERVAL"
  done
}

monitor_loop
